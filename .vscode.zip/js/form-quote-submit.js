// const buttonSubmit = document.getElementById('quoteButton');
// const nameQuote = document.getElementById("quoteName");
// const phoneQuote = document.getElementById('quoteTel');
// const messageQuote = document.getElementById('message')

// buttonSubmit.addEventListener("click", e=>
//     console.log(e)
// )

//   document.getElementById('quoteForm').addEventListener('submit', function(e) {
//     e.preventDefault();

//     emailjs.sendForm('service_a0tjego', 'template_pvngxw4', this)
//       .then(function() {
//         alert('Відгук успішно надіслано!');
//       }, function(error) {
//         console.log('Помилка:', error);
//         alert('Помилка надсилання.');
//       });
//   });